package com.capgemini.dao;


import java.sql.Date;
import java.util.List;

/************************************************************************************
 * File:        BankDaoImpl.java
 * Package:     com.capgemini.dao
 * Description:        Dao class for Online Banking System (admin)
 * Version:     3.0
 * Author: Group5            Date:02/02/2017        
 ************************************************************************************/

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;





import com.capgemini.entity.AccountMaster;
import com.capgemini.entity.Customer;
import com.capgemini.entity.DateForm;
import com.capgemini.entity.FundTransfer;
import com.capgemini.entity.PayeeTable;
import com.capgemini.entity.ServiceTracker;
import com.capgemini.entity.Transaction;
import com.capgemini.entity.UserTable;
import com.capgemini.exception.BankingException;
import com.capgemini.logger.LogInfo;

@Repository
public class BankDaoImpl implements IBankDao 
{
	@PersistenceContext
	private EntityManager manager;
	
	Logger myLog;
	
	public BankDaoImpl()
	{
		myLog=Logger.getLogger(LogInfo.class);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IBankDao#insertAccountHolder(com.capgemini.entity.Customer)
	 */
	@Override
	public int insertAccountHolder(Customer customer) throws BankingException 
	{
		 manager.persist(customer);
		 Customer cust= manager.find(Customer.class,customer.getAccountId());
		 if(cust==null)
		 {
			myLog.info("Server error. Contact Bank 1800-5424-800");
			throw new BankingException("Server Error. Contact bank @1800-5424-800");
		 }
		 else
		 {
			 myLog.info("Customer has been inserted successfully.");
			 return cust.getAccountId();
		 }
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IBankDao#insertAccount(com.capgemini.entity.AccountMaster)
	 */
	@Override
	public int insertAccount(AccountMaster account) throws BankingException {
		manager.persist(account);
		AccountMaster acc= manager.find(AccountMaster.class,account.getAccountId());
		 if(acc==null)
		 {
			myLog.info("Server Error. Contact bank @1800-5424-800");
			throw new BankingException("Server Error. Contact bank @1800-5424-800");
		 }

		 else
		 {
			 myLog.info("New Account has been created");
			 return acc.getAccountId();			 
		 }
	}

	

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IBankDao#deleteAccount(int)
	 */
	@Override
	public int deleteAccount(int accountId) throws BankingException 
	{
		
		
		
	
		String query="select user from UserTable user where accountId=:paccountId";
		TypedQuery<UserTable> query1 = manager.createQuery(query, UserTable.class);
		query1.setParameter("paccountId", accountId);
		UserTable user=query1.getSingleResult();
		
		manager.remove(user);

		AccountMaster master=manager.find(AccountMaster.class, accountId);
		if(master!=null)
			manager.remove(master);
		AccountMaster master1=manager.find(AccountMaster.class, accountId);
		Customer cust1=manager.find(Customer.class, accountId);
				
		if(cust1==null && master1==null)
		{
			myLog.info("Deleted Successfully");
			return 1;
		}
		else
		{
			myLog.info("Failed to delete the account.");
			return 0;
		}
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IBankDao#updateTracker(int)
	 */
	@Override
	public ServiceTracker updateTracker(int serviceId) {
		ServiceTracker track = new ServiceTracker();
		track=manager.find(ServiceTracker.class, serviceId);
		return track;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IBankDao#updateTrack(com.capgemini.entity.ServiceTracker)
	 */
	@Override
	public void updateTrack(ServiceTracker track) throws BankingException {
		try 
		{
			manager.merge(track);
		} 
		catch (Exception e) 
		{
			myLog.info("Technical fault... Unable to update");
			throw new BankingException("Technical fault... Unable to update");
		}
		
	}

	@Override
	public List<FundTransfer> trackTransaction(Date fromDate , Date toDate) throws BankingException {
		// TODO Auto-generated method stub
		
		Query query = manager.createQuery("From FundTransfer where dateOfTransaction between :date_of_transfer and :date_of_transfer");
		query.setParameter("date_of_transfer", fromDate);
		query.setParameter("date_of_transfer", toDate);
		List<FundTransfer> list = query.getResultList();
		return list;
	}
	

}
