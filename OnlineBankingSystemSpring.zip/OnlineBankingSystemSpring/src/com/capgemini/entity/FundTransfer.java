
package com.capgemini.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity(name = "FundTransfer")
@Table(name = "FundTransfer")
public class FundTransfer
{
	
	@Id
	@Column(name = "FundTransferId")
	@GeneratedValue(generator="fund_seq", strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(sequenceName="fund_seq", name="fund_seq", initialValue=1000, allocationSize=1)
	private int fundTransferId;
	
	
	@Column(name="Account_Id")
	@NotNull(message="Account Id cannot be Null")
	@Min(value=4, message="Minimum 4 and Maximum 10 digits allowed.")
	private int accountId;
	
	@Column(name="Payee_Account_Id")
	@NotNull(message="payeeAccount Id cannot be Null")
	@Min(value=4, message="Minimum 4 and Maximum 10 digits allowed.")
	private int payeeAccountId;
	
	
	@Column(name = "Date_of_Transfer")
	@Temporal(TemporalType.DATE)
	private Date dateOfTransaction=new Date();
	
	@Column(name = "Transfer_Amount")
	@NotNull(message= "transfer amount field should not be empty")
	private Double transferAmount;
	
	
	public FundTransfer() {
		super();
	}


	public FundTransfer(int fundTransferId, int accountId, int payeeAccountId,
			Date dateOfTransaction, Double transferAmount) {
		super();
		this.fundTransferId = fundTransferId;
		this.accountId = accountId;
		this.payeeAccountId = payeeAccountId;
		this.dateOfTransaction = dateOfTransaction;
		this.transferAmount = transferAmount;
	}


	public int getFundTransferId() {
		return fundTransferId;
	}


	public void setFundTransferId(int fundTransferId) {
		this.fundTransferId = fundTransferId;
	}


	public int getAccountId() {
		return accountId;
	}


	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}


	public int getPayeeAccountId() {
		return payeeAccountId;
	}


	public void setPayeeAccountId(int payeeAccountId) {
		this.payeeAccountId = payeeAccountId;
	}


	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}


	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}


	public Double getTransferAmount() {
		return transferAmount;
	}


	public void setTransferAmount(Double transferAmount) {
		this.transferAmount = transferAmount;
	}


	@Override
	public String toString() {
		return "FundTransfer [fundTransferId=" + fundTransferId
				+ ", accountId=" + accountId + ", payeeAccountId="
				+ payeeAccountId + ", dateOfTransaction=" + dateOfTransaction
				+ ", transferAmount=" + transferAmount + "]";
	}
	
	
	
}
