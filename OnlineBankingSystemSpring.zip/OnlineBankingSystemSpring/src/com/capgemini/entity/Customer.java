package com.capgemini.entity;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;


@Entity(name="Customer")
@Table(name="Customer")
public class Customer extends AccountId
{
	
	@Id
	@Column(name="Account_Id")
	@NotNull(message="Account Id cannot be Null")
	@Min(value=4, message="Minimum 4 and Maximum 10 digits allowed.")
	@GeneratedValue(generator="accountcust_seq", strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(sequenceName="accountcust_seq", name="accountcust_seq", initialValue=3000, allocationSize=1)
	private int accountId;
		
	@Column(name="Customer_Name")
	@NotEmpty(message="Name cannot be empty.")
	@Size(min=2, max=50, message="Name cannot be less than 2 and greater than 50 characters.")
	private String customerName;
	
	@Column(name="Email")
	@Pattern(regexp="^[a-z0-9._]*@[a-z]*.(com|in|org)", message="Enter a valid email id.")
	@NotEmpty(message="email field is mandatory")
	private String email;
	
	@Column(name="Address")
	@Size(min=2, max=100, message="Address size between 2 and 100 characters.")
	@NotEmpty(message="Address field cannot be empty.")
	private String address;
	
	@Column(name="Pancard")
	@NotEmpty(message="Pancard cannot be empty.")
//	@Pattern(regexp="[A-Z]{5}[0-9]{4}[A-Z]" , message="please input a valid pan No")
	private String panCard;

	@OneToOne(mappedBy="customer", cascade=CascadeType.ALL)
	private AccountMaster accountMaster;

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public AccountMaster getAccountMaster() {
		return accountMaster;
	}

	public void setAccountMaster(AccountMaster accountMaster) {
		this.accountMaster = accountMaster;
	}

	@Override
	public String toString() {
		return "Customer [accountId=" + accountId + ", customerName="
				+ customerName + ", email=" + email + ", address=" + address
				+ ", panCard=" + panCard + ", accountMaster=" + accountMaster
				+ "]";
	}

	public Customer(int accountId, String customerName, String email,
			String address, String panCard, AccountMaster accountMaster) {
		super();
		this.accountId = accountId;
		this.customerName = customerName;
		this.email = email;
		this.address = address;
		this.panCard = panCard;
		this.accountMaster = accountMaster;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	


	
}
