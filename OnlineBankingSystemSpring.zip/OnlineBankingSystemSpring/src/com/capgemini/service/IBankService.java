package com.capgemini.service;

import java.sql.Date;
import java.util.List;

import com.capgemini.entity.AccountMaster;
import com.capgemini.entity.Customer;
import com.capgemini.entity.DateForm;
import com.capgemini.entity.FundTransfer;
import com.capgemini.entity.ServiceTracker;
import com.capgemini.entity.Transaction;
import com.capgemini.exception.BankingException;

public interface IBankService 
{
	public int insertAccountHolder(Customer customer) throws BankingException;
	public int insertAccount(AccountMaster account) throws BankingException;
	
	
	int deleteAccount(int accountId) throws BankingException;
	public ServiceTracker updateTracker(int serviceId);
	public void updateTrack(ServiceTracker track) throws BankingException;
	public List<FundTransfer> trackTransaction(Date fromDate , Date toDate) throws BankingException;
}
