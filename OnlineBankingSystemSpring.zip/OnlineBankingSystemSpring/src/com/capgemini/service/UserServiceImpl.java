package com.capgemini.service;
/************************************************************************************
 * File:        BankDaoImpl.java
 * Package:     com.capgemini.service
 * Description:        Service class for Online Banking System (user)
 * Version:     3.0
 * Author: Group5            Date:02/02/2017        
 ************************************************************************************/

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.dao.IUserBankDao;
import com.capgemini.entity.AccountMaster;
import com.capgemini.entity.Customer;
import com.capgemini.entity.FundTransfer;
import com.capgemini.entity.PayeeTable;
import com.capgemini.entity.ServiceTracker;
import com.capgemini.entity.Transaction;
import com.capgemini.entity.UserTable;
import com.capgemini.exception.BankingException;

@Service
@Transactional
public class UserServiceImpl implements IUserService
{

	@Autowired
	private IUserBankDao daou;	



	/* (non-Javadoc)
	 * @see com.capgemini.service.IUserService#login(int, java.lang.String)
	 */
	@Override
	public UserTable login(int userId, String password) throws BankingException 
	{
		UserTable user = daou.login(userId);
		if(user.getLoginPassword().equals(password))
			return user;
		else 
			return null;
	
	}

	/* (non-Javadoc)
	 * @see com.capgemini.service.IUserService#register(com.capgemini.entity.UserTable)
	 */
	@Override
	public boolean register(UserTable user) throws BankingException {
		
		return daou.register(user);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.service.IUserService#getDetailsMini(int)
	 */
	@Override
	public List<FundTransfer> getDetailsMini(int accountNo)
			throws BankingException {
		
		return daou.getDetailsMini(accountNo);
	}


	

	/* (non-Javadoc)
	 * @see com.capgemini.service.IUserService#serviceView(int)
	 */
	@Override
	public ServiceTracker serviceView(int account2)
			throws BankingException {
		
		return daou.serviceView(account2);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.service.IUserService#changePassword(int, java.lang.String)
	 */
	@Override
	public int changePassword(int userId, String password)
			throws BankingException {
		
		return daou.changePassword(userId, password);
	}



	/* (non-Javadoc)
	 * @see com.capgemini.service.IUserService#ownFundTransfer(int, int, double)
	 */
	@Override
	public int ownFundTransfer(int accountPayer, int accountPayee,
			double amount) throws BankingException{
		
		return daou.ownFundTransfer(accountPayer, accountPayee, amount);
		
	}



	/* (non-Javadoc)
	 * @see com.capgemini.service.IUserService#addPayee(com.capgemini.entity.PayeeTable)
	 */
	@Override
	public void addPayee(PayeeTable payee) throws BankingException {
		
		daou.addPayee(payee);
		
	}

	/* (non-Javadoc)
	 * @see com.capgemini.service.IUserService#getUser(int)
	 */
	@Override
	public UserTable getUser(int userId) {
		
		return daou.getUser(userId);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.service.IUserService#getBalance(int)
	 */
	@Override
	public double getBalance(int accountId) {
		return daou.getBalance(accountId);
	}


	/* (non-Javadoc)
	 * @see com.capgemini.service.IUserService#reqCheckBook(com.capgemini.entity.ServiceTracker)
	 */
	@Override
	public int reqCheckBook(ServiceTracker service) throws BankingException {
		
		return daou.reqCheckBook(service);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.service.IUserService#fetchPayee(int)
	 */
	@Override
	public List<PayeeTable> fetchPayee(int accountId) {
		
		return daou.fetchPayee(accountId);
	}

	@Override
	public String getName(int accountId) {
		// TODO Auto-generated method stub
		return daou.getName(accountId);
	}

	@Override
	public List<ServiceTracker> getList(int accountId) {
		// TODO Auto-generated method stub
		return daou.getList(accountId);
	}

	@Override
	public Customer getCustomer(int accountId) {
		// TODO Auto-generated method stub
		return daou.getCustomer(accountId);
	}

	@Override
	public void updateCust(int accountId, Customer customer) {
		daou.updateCust(accountId, customer);
		
	}
	
	


}
