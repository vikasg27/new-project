

drop table customer cascade constraints;
drop table ACCOUNTMASTER cascade constraints;
drop table payeetable cascade constraints;
drop table user_Table;
drop table ServiceTracker;
drop table FundTransfer;
drop table transaction;


truncate table customer ;
truncate table accountmaster ;
truncate table payeetable ;
truncate table user_Table;
truncate table ServiceTracker;
truncate table FundTransfer;
truncate table transaction;



create table AccountMaster(
Account_Id number(10) primary key,
Account_Type varchar2(25),
Account_Balance number(15),
Open_Date Date
);


create table Customer(
Account_Id number(10) references AccountMaster(Account_Id),
Customer_Name varchar2(50),
Email varchar2(30),
Address varchar2(100),
Pancard varchar2(15)
);

create table PayeeTable(
Account_Id number references AccountMaster(Account_Id),
Payee_Account_Id number ,
Nickname varchar2(40)
);

create table FundTransfer(
FundTransferId number,
Account_Id number(10) references AccountMaster(Account_Id),
Payee_Account_Id number(10) references AccountMaster(Account_Id),
Date_of_Transfer Date,
Transfer_Amount number(15)
);



create table User_Table(
Account_Id number(10) references AccountMaster(Account_Id),
User_Id number primary key,
Login_Password varchar2(256),
Secret_Question varchar2(50),
Transaction_password varchar2(15),
Lock_Status varchar2(1)
);
 alter table user_table modify login_password varchar2(256);


create table ServiceTracker(
Service_Id number primary key,
Service_Description varchar2(100),
Account_Id number(10) references AccountMaster(Account_Id),
Service_Raised_Date Date,
Service_Status varchar2(20)
);



create table Transaction(
Transaction_Id number primary key,
Tran_Description varchar2(100),
DateofTransaction Date,
TransactionType varchar2(180),
TranAmount number(15),
Account_No number(10)
);


create sequence account_seq
start with 3000
increment by 1;


create sequence serv_seq
start with 1000
increment by 1;



create sequence fundtran_seq
start with 2000
increment by 1;


create sequence tran_seq
start with 5000
increment by 1;

drop sequence account_seq;
drop sequence serv_seq;
drop sequence fundtran_seq;
drop sequence tran_seq;

select account_seq.nextval from dual;
select serv_seq.nextval from dual;
select fundtran_seq.nextval from dual;
select tran_seq.nextval from dual;


select * from customer;
select * from accountmaster;
select * from payeetable;
select * from user_Table;
select * from ServiceTracker;
select * from FundTransfer;
select * from transaction;

insert into ACCOUNTMASTER values(account_seq.nextval,'Savings',13000,sysdate);
insert into ACCOUNTMASTER values(account_seq.nextval,'Current',18000,sysdate);
insert into ACCOUNTMASTER values(account_seq.nextval,'Joint',17000,sysdate);
insert into ACCOUNTMASTER values(account_seq.nextval,'Current',19000,sysdate);
insert into ACCOUNTMASTER values(account_seq.nextval,'Savings',12000,sysdate);
insert into ACCOUNTMASTER values(account_seq.nextval,'Current',27000,sysdate);
insert into ACCOUNTMASTER values(account_seq.nextval,'Savings',11000,sysdate);
insert into ACCOUNTMASTER values(account_seq.nextval,'Joint',26000,sysdate);
insert into ACCOUNTMASTER values(account_seq.nextval,'Joint',32000,sysdate);
insert into ACCOUNTMASTER values(account_seq.nextval,'Savings',24000,sysdate);



insert into CUSTOMER values(3001,'SUBIR','subir@gmail.in','Pune','BLIH6574G');
insert into CUSTOMER values(3002,'Pratik','suba@gmail.in','Pune','BLIH6578G');
insert into CUSTOMER values(3003,'Raya','subh@gmail.in','Pune','BLIH3657G');
insert into CUSTOMER values(3004,'Shailja','shelly@gmail.in','Pune','BLIH4125G');
insert into CUSTOMER values(3005,'Srijita','suas@gmail.in','Pune','BLIH4563G');
insert into CUSTOMER values(3006,'Shalini','sqw@gmail.in','Pune','BLIH8924G');
insert into CUSTOMER values(3007,'Pratibha','sasd@gmail.in','Pune','BLIH7410G');
insert into CUSTOMER values(3008,'Rony','suop@gmail.in','Pune','BLIH9630G');
insert into CUSTOMER values(3009,'Mamun','prat@gmail.in','Pune','BLIH8541G');
insert into CUSTOMER values(3000,'Amit','raya@gmail.in','Pune','BLIH9851G');



insert into TRANSACTION values(3265984388,'Savings',13000,sysdate,);
insert into TRANSACTION values(2365987386,'Current',18000,sysdate);
insert into TRANSACTION values(6225984386,'Joint',17000,sysdate);
insert into TRANSACTION values(4265284876,'Current',19000,sysdate);
insert into TRANSACTION values(3261983886,'Savings',12000,sysdate);
insert into TRANSACTION values(8265943886,'Current',27000,sysdate);
insert into TRANSACTION values(9327986388,'Savings',11000,sysdate);
insert into TRANSACTION values(1269843886,'Joint',26000,sysdate);
insert into TRANSACTION values(3219843686,'Joint',32000,sysdate);
insert into TRANSACTION values(2616852686,'Savings',24000,sysdate);

insert into USER_TABLE values(3001,3212,'Subir','What is your pet name?','rocket','U');
insert into USER_TABLE values(3002,5244,'Pratik','What is your pet name?','doggy','U');
insert into USER_TABLE values(3003,7854,'Raya','What is your pet name?','john','U');
insert into USER_TABLE values(3004,8523,'Shailja','What is your pet name?','lalu','U');
insert into USER_TABLE values(3005,7412,'Srijita','What is your nickname?','sri','U');
insert into USER_TABLE values(3006,7841,'Shalini','What is your nickname?','shalu','U');
insert into USER_TABLE values(3007,9652,'Pratibha','What is your nickname?','pratz','U');
insert into USER_TABLE values(3008,3524,'Rony','What is your nickname?','ron','U');
insert into USER_TABLE values(3009,4563,'Mamun','What is your pet name?','rocket','U');
insert into USER_TABLE values(3000,8641,'Amit','What is your nickname?','ami','U');

insert into PAYEETABLE values(3001,3002,'Pratik');
insert into PAYEETABLE values(3002,3001,'SUBIR');
insert into PAYEETABLE values(3003,3001,'Rony');
insert into PAYEETABLE values(3004,3001,'Shalini');
insert into PAYEETABLE values(3005,3001,'Pratibha');
insert into PAYEETABLE values(3006,3001,'Amit');
insert into PAYEETABLE values(3007,3001,'Mamun');
insert into PAYEETABLE values(3008,3001,'Shailja');
insert into PAYEETABLE values(3009,3001,'Raya');
