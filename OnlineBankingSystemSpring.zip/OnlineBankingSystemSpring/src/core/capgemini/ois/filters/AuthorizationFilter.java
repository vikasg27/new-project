package core.capgemini.ois.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class AuthorizationFilter
 */
@WebFilter("*.jsp")
public class AuthorizationFilter implements Filter {

    /**
     * Default constructor. 
     */
    public AuthorizationFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		HttpSession session = null;
		
		HttpServletRequest req = (HttpServletRequest)request;
		HttpServletResponse res = (HttpServletResponse)response;
		
		System.out.println("filter called");
		
		String action = req.getRequestURI();
		System.out.println(action);				
		
		System.out.println(action.equals("/OnlineBankingSystem/index.jsp"));
		
		if(action.equals("/OnlineBankingSystemSpring/") || action.equals("/OnlineBankingSystem/") 
				|| action.equals("/OnlineBankingSystem/securityQues.jsp") ||  action.equals("/OnlineBankingSystem/adminlogin.jsp") 
				||action.equals("/OnlineBankingSystem/register.jsp") || action.equals("/OnlineBankingSystem/index.jsp"))
		{
			chain.doFilter(req, res);
		}
		else
		{
			session = req.getSession(false);
			
			if(session == null || session.getAttribute("user12") == null )
			{
				session = req.getSession(true);
				req.getRequestDispatcher("login.do").forward(req, res);
				session.setAttribute("msg","Please Login First");
				return;
			}
			else
			{
				chain.doFilter(req, res);
			}
		}
		
		
//		if(action.equals("/OnlineBankingSystem/ClientLogin.jsp") || action.equals("/OnlineBankingSystem/index.jsp"))
//		{
//			chain.doFilter(request , response);
//		}
//		
//		Object obj = session.getAttribute("userId");
//		if(obj == null || obj.toString().equals("")){
//			session.setAttribute("msg", "Please login to access "+req.getRequestURI());
//			res.sendRedirect("ClientLogin.jsp");
//			
//		}
//		else
//		// pass the request along the filter chain
//		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
